/**
 * define updateOptions 
 * 
 ***/
cr.define('options', function() {
    var OptionsPage = options.OptionsPage;

    function UpdateOptions() {
        OptionsPage.call(this, 'update', '选项 - 版本更新', 'updatePage');
    }

    cr.addSingletonGetter(UpdateOptions);
    
    UpdateOptions.prototype = {
        __proto__: options.OptionsPage.prototype,

        initializePage: function(){
            OptionsPage.prototype.initializePage.call(this);
            window.setCurrentVersion = function(version) {
		        $$('#version_num').text(version);
	     	};
			$('check_version').onclick = function(){
				gif('911.3082.gif');
				chrome.send('checkNewVersion');
			}
			$('ent-link').onclick = function(){
				gif('911.1974.gif');
				window.open('https://browser.360.cn/se/ver/ent.html');
			}
        }
    };

    return {
        UpdateOptions: UpdateOptions
    };
});