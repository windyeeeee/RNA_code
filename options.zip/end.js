(function() {
  document.body.hidden = false;
})();